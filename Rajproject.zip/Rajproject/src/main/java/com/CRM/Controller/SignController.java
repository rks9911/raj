





package com.CRM.Controller;




import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.CRM.Service.Menilsignupervice;


@Controller

public class SignController
{

	//@Autowired
	//private Menilsignupervice loginService;

	Menilsignupervice loginService=new Menilsignupervice();
	
	
		@RequestMapping(value = "/signup", method = RequestMethod.POST)
	@ResponseBody
	// Method for SignUp User 
	public ModelAndView  AddUser(HttpServletRequest request) {
			System.out.println("this is controller");
			String name=request.getParameter("name");
			String pwd=request.getParameter("pwd");
			System.out.println(name);
			System.out.println(pwd);
		String status = "";
		
		status = loginService.signUpLogic(name,pwd);
		return new ModelAndView("hello","status1",status);
	}

		
			
		
	}

		
	
