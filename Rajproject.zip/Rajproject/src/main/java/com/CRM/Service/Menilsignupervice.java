package com.CRM.Service;




import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.CRM.Dao.MenilySignupDAO;
import com.CRM.Entity.MenilyLogin;



@Service

public class Menilsignupervice {
	//@Autowired
	//private MenilySignupDAO loginDAO;
	
	MenilySignupDAO loginDAO=new MenilySignupDAO();
	
	//@Autowired
	//private MenilyLogin menilylogin;
	
	
	
	
	/* Method for signUp */
	@Transactional
	public String signUpLogic(String name, String pwd) {
		// TODO Auto-generated method stub
		MenilyLogin menilylogin =new MenilyLogin();
		String status = "";
		System.out.println("name print in service"+name);
		System.out.println("name print in service"+pwd);
		try
		{
		menilylogin.setMenilyUsername(name);
		menilylogin.setMenilyPassword(pwd);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		System.out.println("name print inafter set service"+name);
		System.out.println("name print in after set service"+pwd);

		//MenilyLogin menily = loginDAO.FindUser(menilylogin.getMenilyUsername());
		//MenilyLogin menily =new MenilyLogin();
	
			System.out.println("menily==null in service................"+name);
			status = "signUp Sucessfull";
			loginDAO.addUser(menilylogin);
			
			
			
				return status;
	
			
		
		}
	

	public String loginLogic(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

	

/*@Transactional
	public String loginLogic(HttpServletRequest request) {
		// TODO Auto-generated method stub
		String status = "";
		String username = request.getParameter("LoginUsername");
		String password = request.getParameter("LoginPassword");
		


		String menily = loginDAO.User_present(username,password);

		if (menily.equals("null")) {
			status = "please enter correct details";
			
				return status;
			} else {
			status = "login done";
			
			return status;
		}*/
	}




