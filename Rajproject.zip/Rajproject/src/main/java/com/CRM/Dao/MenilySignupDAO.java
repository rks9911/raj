package com.CRM.Dao;



import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.CRM.Entity.MenilyLogin;





@Repository

public class MenilySignupDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	

	public void addUser1(MenilyLogin logins) {
		try {
System.out.println("this is add user in dao");
System.out.println("name in dao adduser before"+logins.getMenilyUsername());
System.out.println("name in dao adduser before"+logins.getMenilyPassword());

sessionFactory.getCurrentSession().saveOrUpdate(logins);

			
			System.out.println("name in dao adduser"+logins.getMenilyUsername());
			System.out.println("name in dao adduser"+logins.getMenilyPassword());

		} catch (Exception e) {
			System.out.println("this is in catch of add user dao");
			e.getMessage();
		}
	}
	

	public String addUser(MenilyLogin logins) {
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(MenilyLogin.class.getName(), logins);
			return "Success";
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
			return "Try Again!";

		}
	}
	
	

	@SuppressWarnings("unchecked")
	public MenilyLogin FindUser(String uname) {
		List<MenilyLogin> loginlist = null;
		System.out.println("nikhil Before in DAO"+uname);

		try {

			loginlist = (List<MenilyLogin>) sessionFactory.getCurrentSession().createQuery("FROM MenilyLogin WHERE MenilyUsername='" + uname+ "'").list();
			System.out.println("raj Query Executed");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("raj kumar sharma");
		}
		if (loginlist == null || loginlist.isEmpty()) {
			System.out.print("loginlist null");
			return null;

		} else {
			System.out
					.println(loginlist.get(0).getMenilyUsername() + " inside"+uname);

			return loginlist.get(0);
		}
	}

	/*@SuppressWarnings("unchecked")
	public String User_present(String uname,String pass) {
		List<MenilyLogin> loginlist = null;
		System.out.println("Before in DAO");

		try {

			loginlist = (List<MenilyLogin>) sessionFactory.getCurrentSession().createQuery("FROM MenilyLogin WHERE MenilyUsername='" +uname+ "'and MenilyPassword='"+pass+"'").list();
			System.out.println("Query Executed");
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (loginlist == null || loginlist.isEmpty()) {
			System.out.print("loginlist null");
			return "null";

		} else {
			System.out.println(loginlist.get(0).getMenilyUsername() + " inside");

			//return "hai";
			return "hai";
		}
	}

	
	
	
	
	public static void main(String[] args) {

	}*/
}
