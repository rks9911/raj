package com.CRM.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MenilyLogin", catalog = "raj")
public class MenilyLogin {
	

	@Id
	private String MenilyUsername;
	

	
	
	private String MenilyPassword;



	public String getMenilyUsername() {
		return MenilyUsername;
	}



	public void setMenilyUsername(String menilyUsername) {
		MenilyUsername = menilyUsername;
	}



	public String getMenilyPassword() {
		return MenilyPassword;
	}



	public void setMenilyPassword(String menilyPassword) {
		MenilyPassword = menilyPassword;
	}
	
	
	
		
	
}
